<?php  
 	foreach($row as $r) {
?>
  <div class="col-lg-4"> 
	   <div class="card">
	    	<img class="card-img-top" src="<?php echo base_url();?>upload_img/<?php echo $r->pimg;?>" style="width:150px">	
	    	<div class="card-body">
	    		<h4 class="card-title"><?php echo $r->pname; ?></h4>
	    		<p class="card-text"><?php echo $r->price; ?></p>
	    		<a href="#" class="card-link"><?php echo $r->catname; ?></a>
	              
	            <?php  
	              $cname = $this->session->userdata("cname");
	              if($cname != ""){
	            ?>
	            <form action="<?php echo base_url(); ?>add-to-cart" method="POST">
	                <input type="hidden" name="pid" value="<?php echo $r->pid; ?>">
	                <input type="hidden" name="price" value="<?php echo $r->price; ?>">
	                <input type="number" min="1" value="1" name="qty">
	                <input type="submit" value="Add to Cart" class="btn btn-primary">
	            </form>
	            <?php 
	              }else{
	            ?>
	                <button class="btn btn-primary float-right" onclick="logfun();">Add To Cart</button>
	            <?php  
	              } 
	            ?>
	    	</div>
	    </div>
    </div>
<?php		
 }
?>