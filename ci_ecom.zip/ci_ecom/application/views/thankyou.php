<!DOCTYPE html>
<html lang="en">
<head>
  <title>Thnak you</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>

  <h1 style="text-align: center; margin-top: 100px;">Order done successfully!</h1>


<script>
  setTimeout(function(){ 
      window.location="<?php echo base_url(); ?>"
   }, 2000);
</script>
</body>
</html>
