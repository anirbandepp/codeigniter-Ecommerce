<!-- Header Area include -->
<?php $this->load->view("./frontend/header.php"); ?>
<!-- Navbar Area include -->
<?php $this->load->view("./frontend/navbar.php"); ?>

  <section class="cart-area pt-5">
    <div class="container">
        
       <p> <b>My Cart</b> </p>
        <table class="table" id="cart_table">
        <thead>
            <tr>
              <th>Product Name</th>
              <th>Image</th>
              <th>Quantity</th>
              <th>Price</th>
            </tr>
        </thead>
        <tbody>
          <?php  
           $st = 0;
            foreach ($row as $r) {
              $st = $st+($r->price*$r->qty);
          ?>
        <tr>
          <td>
            <?php echo $r->pname; ?>
          </td>
          <td>
            <img src="<?php echo base_url(); ?>upload_img/<?php echo $r->pimg ?>" style="width: 150px;">
          </td>
          <td>
            <form id="frm<?php echo $r->cartid; ?>">
                <input type="hidden" name="cartid" value="<?php echo $r->cartid;?>">
                <input type="number" min="1" value="<?php echo $r->qty;?>" name="qty"
                 onclick="updcart(<?php echo $r->cartid;?>)"
                 onkeyup="updcart(<?php echo $r->cartid;?>)">
            </form>
          </td>
          <td>
            <?php echo $r->price*$r->qty; ?>
          </td>
        </tr>
        <?php } ?>
        <tr>
          <td colspan="1">  
            <a href="index.php" class="btn btn-success"> Continue Shopping</a>
          </td>
          <td colspan="1"> <b>Grand Total</b> </td>
          <td>
              <?php echo $st;?> 
          </td>
          <td colspan="1">
            <a href="<?php echo base_url() ?>checkout" class="btn btn-info">
              Checkout
            </a> 
          </td>
        </tr>
        </tbody>
      </table>
    </div>
  </section>

  <script>
      function updcart(id) {
        $.ajax({
          url : '<?php echo base_url(); ?>cart-update',
          type : 'POST',
          data : $("#frm"+id).serialize(),
          success : function(response) {
              $("#cart_table").html(response);
              console.log(response);
          }
        });
      }
  </script>

<!-- Footer Area include -->
<?php $this->load->view("./frontend/footer.php"); ?>