<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>


<script>
  window.onload=function(){
    pay_now();
  }
  
    function pay_now(){
        var name='<?php echo $name; ?>';
        var amt='<?php echo $gt; ?>';
        
         jQuery.ajax({
               type:'post',
               url:'<?php echo base_url(); ?>payment_process',
               data:"amt="+amt+"&name="+name,
               success:function(result){
                   var options = {
                        "key": "rzp_test_of9LfvpWbrkgom", 
                        "amount": amt*100, 
                        "currency": "INR",
                        "name": "Anirban Shop",
                        "description": "Test Transaction",
                        "image": "https://image.freepik.com/free-vector/logo-sample-text_355-558.jpg",
                        "handler": function (response){
                           jQuery.ajax({
                               type:'post',
                               url:'<?php echo base_url(); ?>payment_process',
                               data:"payment_id="+response.razorpay_payment_id,
                               success:function(result){
                                   window.location.href="<?php echo base_url(); ?>thank_you";
                               }
                           });
                        }
                    };
                    var rzp1 = new Razorpay(options);
                    rzp1.open();
               }
           });
        
        
    }
</script>