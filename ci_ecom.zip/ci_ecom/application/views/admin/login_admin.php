<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Login</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link href="<?php echo base_url();?>admin/css/style.css" rel="stylesheet">
</head>
<body class="loginPage">

    <div class="login_frm">
        <form action="<?php echo base_url(); ?>cpnale/login-check/" method="POST">
            <p>
                <input type="text" placeholder="Email" name="email" class="form-control">
            </p>
            <p>
                <input type="text" placeholder="Password" name="pass" class="form-control">
            </p>
            <input type="submit" value="Log In" class="btn btn-success">

            <p class="error_msg">
                <?php  
                    if($this->session->flashdata('msg')!="") {
                        echo $this->session->flashdata('msg');
                    }
                ?>
            </p>
        </form>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
