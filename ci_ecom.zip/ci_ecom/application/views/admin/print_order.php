<!DOCTYPE html>
<html lang="en">
<head>
  <title>Print Bill</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    .billNo {
      text-align: left;
      padding-left: 5%;
      color: green;
      font-weight: bold;
      text-decoration: underline;
    }
  </style>
</head>
<body>

  <div class="jumbotron text-center">
    <p class="billNo"> 
      Bill No. SW<?php echo str_pad($row[0]->id, "8","0",STR_PAD_LEFT); ?>   
    </p>
    <h1>Anirban Store</h1>
    <p>Online Ecommerce Store</p> 
  </div>
    
  <div class="container">
      <?php  
        foreach($row as $r) {
      ?>
      <div class="row">
        <div class="col-md-6">
            <p>Billing Name: <?php echo $r->bn; ?> </p>
            <p>Billing Phone: <?php echo $r->bp; ?> </p>
            <p>Billing Address: <?php echo $r->ba; ?> </p>
        </div>
        <div class="col-md-6">
            <p>Shipping Name: <?php echo $r->sn; ?> </p>
            <p>Shipping Phone: <?php echo $r->sp; ?> </p>
            <p>Shipping Address: <?php echo $r->sa; ?> </p>
        </div>
      </div>
      <?php } ?>

      <table class="table">
        <thead>
          <tr>
            <th>Product Name</th>
            <th>Product Price</th>
            <th>Product Qty</th>
            <th>Total Price</th>
          </tr>
        </thead>
        <tbody>
          <?php  
            $res = $this->Admin_mod->sel_order($row[0]->id);
            $total=0;
            foreach($res as $r) {
          ?>
          <tr>
              <td> 
                <?php  
                  $resp = $this->Admin_mod->pname($r->pid);
                  echo  $resp[0]->pname;
                ?> 
              </td>
              <td> <?php echo $r->price; ?>/- </td>
              <td> <?php echo $r->qty; ?> </td>
              <td> <?php echo $r->price*$r->qty; ?>/- </td>
              <?php  
                $total = $total + $r->price*$r->qty;
              ?>
          </tr>
          <?php  
            }
          ?>
          <tr>
            <th colspan="3" style="text-align: right;">Sub Total</th>
            <th><?php echo $total ?>/-</th>
          </tr>
        </tbody>
      </table>

      <div class="row">
        <div class="col-md-6">
          <p style="float:left;">Date ..............</p>
        </div> 
        <div class="col-md-6">
          <p style="float:right;">Signature ..............</p>
        </div> 
      </div>

  </div>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script>
    window.print();
  </script>
</body>
</html>
