<?php $this->load->view('./admin/inc/header.php'); ?>

<style>
    .page-link {
        float: left;
    }
    .pagination strong {
        float: left;
        display: block;
        padding: 0.5rem 0.75rem;
        margin-left: -1px;
        line-height: 1.25;
        color: #fff;
        background-color: #222;
        border: 1px solid #000;
    }
</style>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php $this->load->view('./admin/inc/sidebar.php'); ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800">View Product</h1>
                   
                    <table class="table">
                        <thead>
                          <tr>
                            <th>PID</th>
                            <th>Category</th>
                            <th>Product Name</th>
                            <th>Prodcut Price</th>
                            <th>Product Imgae</th>
                            <th>Barcode</th>
                            <th>Delete</th>
                            <th>Update</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($row as $r) { ?>  
                            <tr>
                                <td> <?php echo $r->pid; ?> </td>
                                <td> <?php echo $r->catname; ?> </td>
                                <td> <?php echo $r->pname; ?> </td>
                                <td> <?php echo $r->price; ?> </td>
                                <td> 
                                   <img src="<?php echo base_url();?>upload_img/<?php echo $r->pimg;?>" style="width: 150px;">
                                </td>
                                <td> 
                                    <a href="<?php echo base_url();?>cpnale/del-product/<?php echo $r->pid; ?>" 
                                        onclick = "return confirm('Are you sure ?')"
                                        class="btn btn-danger">
                                        Delete
                                    </a> 
                                </td>
                                <td> <a href="<?php echo base_url();?>cpnale/upd-product/<?php echo $r->pid; ?>" 
                                        class="btn btn-primary">
                                        Update
                                    </a>
                                </td>
                            </tr>
                          <?php } ?>
                        </tbody>
                    </table>
                   
                    <!-- Pagination Link -->   
                    <ul class="pagination">
                        <li class="page-item"> 
                            <?php echo $this->pagination->create_links(); ?>
                        </li>
                    </ul>
                    
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <?php $this->load->view('./admin/inc//footer.php'); ?>

</body>

</html>