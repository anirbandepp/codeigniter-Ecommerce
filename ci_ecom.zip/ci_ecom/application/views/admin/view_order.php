<?php $this->load->view('./admin/inc/header.php'); ?>

<style>
    .page-link {
        float: left;
    }
    .pagination strong {
        float: left;
        display: block;
        padding: 0.5rem 0.75rem;
        margin-left: -1px;
        line-height: 1.25;
        color: #fff;
        background-color: #222;
        border: 1px solid #000;
    }

    .modal-dialog {
        max-width: 650px;
    }
</style>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php $this->load->view('./admin/inc/sidebar.php'); ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800">View Orders</h1>
                   
                    <table class="table">
                        <thead>
                          <tr>
                            <th>Order ID</th>
                            <th>Billing Name</th>
                            <th>Shipping Name</th>
                            <th>Shipping Ph No.</th>
                            <th>Print</th>
                            <th>View Details</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php  
                                foreach ($row as $r) {  
                            ?>
                            <tr>
                                <td> <?php echo $r->id ?> </td>
                                <td> <?php echo $r->bn ?> </td>
                                <td> <?php echo $r->sn ?> </td>
                                <td> <?php echo $r->sp ?> </td>

                                <td> 
                                    <a target="_blank" 
                                       href="<?php echo base_url() ?>cpnale/print-order/<?php echo $r->id ?>" 
                                       class="btn btn-danger">
                                        Print
                                    </a>
                                </td>
                                
                                <td> 
                                    <button class="btn btn-primary" data-id="<?php echo $r->id ?>"
                                            data-toggle="modal" data-target="#myModal<?php echo $r->id ?>">
                                        View Details
                                    </button> 
                                    <div class="modal" id="myModal<?php echo $r->id ?>">
                                        <div class="modal-dialog">
                                            <div class="modal-content">

                                                <!-- Modal Header -->
                                                <div class="modal-header">
                                                <h4 class="modal-title">
                                                   Bill No. SW<?php echo str_pad($r->id, "8","0",STR_PAD_LEFT); ?>
                                                </h4>
                                                    <button type="button" class="close" 
                                                            data-dismiss="modal">&times;
                                                    </button>
                                                </div>

                                                <!-- Modal body -->
                                                <div class="modal-body">
                                                    <h5 class="text-danger">Customer Details</h5>
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <p>Billing Name: <?php echo $r->bn; ?> </p>
                                                            <p>Billing Phone: <?php echo $r->bp; ?> </p>
                                                            <p>Billing Address: <?php echo $r->ba; ?> </p>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <p>Shipping Name: <?php echo $r->sn; ?> </p>
                                                            <p>Shipping Phone: <?php echo $r->sp; ?> </p>
                                                            <p>Shipping Address: <?php echo $r->sa; ?> </p>
                                                        </div>
                                                    </div>
                                                    <table class="table table-striped">
                                                        <thead>
                                                            <tr>
                                                                <th>Product Name</th>
                                                                <th>Price</th>
                                                                <th>Quantity</th>
                                                                <th>Totlal</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php  
                                                                $res = $this->Admin_mod->sel_order($r->id);
                                                                foreach($res as $r) {
                                                            ?>
                                                            <tr>
                                                                <td> 
                                                                    <?php  
                                                                        $resp = $this->Admin_mod->pname($r->pid);
                                                                        echo $resp[0]->pname;
                                                                    ?> 
                                                                </td>
                                                                <td> <?php echo $r->price; ?> </td>
                                                                <td> <?php echo $r->qty; ?> </td>
                                                                <td> <?php echo $r->price*$r->qty; ?> </td>
                                                            </tr>
                                                            <?php        
                                                                }
                                                            ?>
                                                        </tbody>
                                                    </table>
                                                </div>

                                                <!-- Modal footer -->
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-danger" data-dismiss="modal">
                                                        Close
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                
                            </tr>
                            <?php
                                }
                            ?>
                        </tbody>
                    </table>
                   
                    <!-- Pagination Link -->   
                    <ul class="pagination">
                        <li class="page-item"> 
                            <?php 
                                // echo $this->pagination->create_links(); 
                            ?>
                        </li>
                    </ul>
                    
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <?php $this->load->view('./admin/inc//footer.php'); ?>

</body>

</html>