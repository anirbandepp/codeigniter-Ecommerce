<?php $this->load->view('./admin/inc/header.php'); ?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php $this->load->view('./admin/inc/sidebar.php'); ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800">Add Product Area</h1>
                   
                    <form action="<?php echo base_url();?>cpnale/ins-product" method="POST" enctype="multipart/form-data">
                        <p>Select Category</p>
                        <p>
                            <select name="category">
                                <option>--Category--</option>
                                <?php  
                                    foreach ($row as $r) {
                                        $scat=$this->Admin_mod->sub_cat($r->id);
                                ?>
                                <optgroup label="<?php echo $r->cat; ?> ">
                                    <?php  
                                        foreach ($scat as $sr) {      
                                    ?>
                                        <option value="<?php echo $sr->id ?>"> <?php echo $sr->cat ?> </option>
                                    <?php } ?>
                                </optgroup> 
                                <?php        
                                    }
                                ?>
                            </select>
                        </p>
                        <p>Add Product Name</p>
                        <p> <input type="text" name="pname"> </p>
                        <p>Add Product Price</p>
                        <p> <input type="text" name="price"> </p>
                        <p>Product Image</p>
                        <p> <input type="file" name="propic"> </p>
                        <input type="submit" class="btn btn-primary" value = "Upload"> 
                    </form> 

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <?php $this->load->view('./admin/inc//footer.php'); ?>

</body>

</html>