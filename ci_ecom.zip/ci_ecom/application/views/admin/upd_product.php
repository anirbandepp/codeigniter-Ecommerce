<?php $this->load->view('./admin/inc/header.php'); ?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php $this->load->view('./admin/inc/sidebar.php'); ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800">Add Product Area</h1>
                   
                    <?php foreach($row as $r) { ?>
                    <form action="<?php echo base_url();?>cpnale/edit-product" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="id" value="<?php echo $r->pid; ?>">
                        <p>Select Category</p>
                        <p>
                            <select name="category">
                               <option>--Update Category--</option>
                               <?php  
                                foreach ($cat as $c) {
                                ?>
                                    <option
                                        <?php  
                                            if($c->id==$r->cat){
                                                echo "Selected";
                                            }
                                        ?>
                                        value="<?php echo $c->id; ?>"
                                    > 
                                        <?php echo $c->cat;?> 
                                    </option>
                                <?php
                                }
                               ?>
                            </select>
                        </p>
                        <p>Add Product Name</p>
                        <p> <input type="text" name="pname" value="<?php echo $r->pname;?>"> </p>
                        <p>Add Product Price</p>
                        <p> <input type="text" name="price" value="<?php echo $r->price;?>"> </p>
                        <p>Product Image</p>
                        <p>
                            <img src="<?php echo base_url();?>upload_img/<?php echo $r->pimg; ?>" style="width: 150px;">
                         </p>   
                        <p> <input type="file" name="propic"> </p>
                        <input type="submit" class="btn btn-primary" value = "Edit"> 
                    </form> 
                    <?php } ?>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <?php $this->load->view('./admin/inc//footer.php'); ?>

</body>

</html>