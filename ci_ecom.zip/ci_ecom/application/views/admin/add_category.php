<?php $this->load->view('./admin/inc/header.php'); ?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php $this->load->view('./admin/inc/sidebar.php'); ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php $this->load->view("./admin/inc/navbar.php"); ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800">Add Category Area</h1>
                    <br>
                    <form action="<?php echo base_url() ?>cpnale/ins-category" method="POST">
                        <p>Parent</p>
                        <p>
                            <select name="pid">
                                <option value="">--No parent--</option>
                                <?php  
                                    foreach ($parent as $r) {
                                ?>
                                    <option value="<?php echo $r->id; ?>">
                                        <?php echo $r->cat; ?>
                                    </option>
                                <?php
                                    }
                                ?>
                            </select>
                        </p>
                        <input type="text" name="addCat">
                        <input type="submit" name="Submit">
                    </form>
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <?php $this->load->view('./admin/inc//footer.php'); ?>

</body>

</html>