<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

    <p style="color: #1c1c1c; margin: 0;">
        Welcome 
        <b>
            <?php echo $this->session->userdata("admin_name"); ?>
        </b> 
    </p>
    <div class="logout" style="margin-left: auto;">
        <a href="<?php echo base_url(); ?>cpnale/login-out" class="btn btn-danger">Logout</a>
    </div>
                    
</nav>