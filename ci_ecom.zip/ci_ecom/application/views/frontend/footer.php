<script src="<?php echo base_url();?>frontend_asset/app.js"></script>

</body>
</html>
