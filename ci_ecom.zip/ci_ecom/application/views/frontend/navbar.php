<nav class="navbar navbar-expand-md bg-dark navbar-dark">
  <a class="navbar-brand" href="<?php echo base_url(); ?>">Navbar</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url(); ?>">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">About us</a>
      </li>

      <?php
      	$cname = $this->session->userdata("cname");
        if($cname != ""){
      ?>
      <li class="nav-item">
        <a class="nav-link" href="#">Welcome <?php echo $cname ;?></a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url(); ?>order_history">Order History</a>
      </li>    

      <li class="nav-item">
        <a type="button" href="<?php echo base_url();?>view-cart" class="nav-link">
          cart <span class="badge badge-danger">
            <?php  
              $res = $this->Frontend_mod->cartCounter();
              echo $res;
            ?>
          </span>
        </a>
      </li>

      <li class="nav-item">
        <a type="button" href="<?php echo base_url(); ?>cLogOut" class="btn btn-primary mx-3">
		      Logout
		    </a>
      </li> 
      <?php
       }else{
      ?>
      <li class="nav-item">
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#LoginModal">
		      Login
		    </button>
      </li>  
      <?php } ?>  
    </ul>
  </div>  
</nav>