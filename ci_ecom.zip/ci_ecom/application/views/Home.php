<!-- Header Area include -->
<?php $this->load->view("./frontend/header.php"); ?>
<!-- Navbar Area include -->
<?php $this->load->view("./frontend/navbar.php"); ?>

	<section class="container-fluid">
    <div class="row">
      <div class="col-lg-2">
          <?php $this->load->view('./sidebar.php');?>
      </div>
      <div class="col-lg-10">
    		<div class="row" id="catProduct">
    			<?php  
    				foreach($row as $r) {
    			?>
    			<div class="col-lg-4"> 
    				<div class="card">
    				  <img class="card-img-top" src="<?php echo base_url();?>upload_img/<?php echo $r->pimg;?>" style="width:150px">	
    				  <div class="card-body">
    				    <h4 class="card-title"><?php echo $r->pname; ?></h4>
    				    <p class="card-text"><?php echo $r->price; ?></p>
    				    <a href="#" class="card-link"><?php echo $r->catname; ?></a>
              
                <?php  
                  $cname = $this->session->userdata("cname");
                  if($cname != ""){
                ?>
                <form action="<?php echo base_url(); ?>add-to-cart" method="POST">
                    <input type="hidden" name="pid" value="<?php echo $r->pid; ?>">
                    <input type="hidden" name="price" value="<?php echo $r->price; ?>">
                    <input type="number" min="1" value="1" name="qty">
                    <input type="submit" value="Add to Cart" class="btn btn-primary">
                </form>
                <?php 
                  }else{
                ?>
                  <button class="btn btn-primary float-right" onclick="logfun();">Add To Cart</button>
                <?php  
                  } 
                ?>
    				  </div>
    				</div>
    			</div>
    			<?php		
    				}
    			?>
         </div>
  		</div>
    </div>
	</section>



<!-- Login Modal -->
<div class="modal" id="LoginModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Login</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form action="<?php echo base_url();?>cLogin" method="post">
        	<p>Email</p>
        	<p><input type="text" name="email" class="form-control"></p>
        	<p>Password</p>
        	<p><input type="text" name="password" class="form-control"></p>
        	<input type="submit" value="Login" class="btn btn-warning">
        </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>

<?php $this->load->view("./frontend/footer.php"); ?>