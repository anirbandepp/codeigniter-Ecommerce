<!-- Header Area include -->
<?php $this->load->view("./frontend/header.php"); ?>
<!-- Navbar Area include -->
<?php $this->load->view("./frontend/navbar.php"); ?>

<div class="container pt-4">
	<table class="table">
                        <thead>
                          <tr>
                            <th>Order ID</th>
                            <th>Billing Name</th>
                            <th>Shipping Name</th>
                            <th>Shipping Ph No.</th>
                            <th>View Details</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php  
                                foreach ($row as $r) {  
                            ?>
                            <tr>
                                <td> <?php echo $r->id ?> </td>
                                <td> <?php echo $r->bn ?> </td>
                                <td> <?php echo $r->sn ?> </td>
                                <td> <?php echo $r->sp ?> </td>
                                <td> 
                                    <button class="btn btn-primary" data-id="<?php echo $r->id ?>"
                                            data-toggle="modal" data-target="#myModal<?php echo $r->id ?>">
                                        View Details
                                    </button> 
                                       <div class="modal" id="myModal<?php echo $r->id ?>">
                                        <div class="modal-dialog">
                                            <div class="modal-content">

                                                <!-- Modal Header -->
                                                <div class="modal-header">
                                                <h4 class="modal-title">Modal Heading <?php echo $r->id; ?> </h4>
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                </div>

                                                <!-- Modal body -->
                                                <div class="modal-body">
                                                    <h2>Customer Details</h2>
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <p>Billing Name: <?php echo $r->bn; ?> </p>
                                                            <p>Billing Phone: <?php echo $r->bp; ?> </p>
                                                            <p>Billing Address: <?php echo $r->ba; ?> </p>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <p>Shipping Name: <?php echo $r->sn; ?> </p>
                                                            <p>Shipping Phone: <?php echo $r->sp; ?> </p>
                                                            <p>Shipping Address: <?php echo $r->sa; ?> </p>
                                                        </div>
                                                    </div>
                                                    <table class="table table-striped">
                                                        <thead>
                                                            <tr>
                                                                <th>Product Name</th>
                                                                <th>Price</th>
                                                                <th>Quantity</th>
                                                                <th>Totlal</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php  
                                                                $res = $this->Frontend_mod->sel_order($r->id);
                                                                foreach($res as $r) {
                                                            ?>
                                                            <tr>
                                                                <td> 
                                                                    <?php  
                                                                        $resp = $this->Frontend_mod->pname($r->pid);
                                                                        echo $resp[0]->pname;
                                                                    ?> 
                                                                </td>
                                                                <td> <?php echo $r->price; ?> </td>
                                                                <td> <?php echo $r->qty; ?> </td>
                                                                <td> <?php echo $r->price*$r->qty; ?> </td>
                                                            </tr>
                                                            <?php        
                                                                }
                                                            ?>
                                                        </tbody>
                                                    </table>
                                                </div>

                                                <!-- Modal footer -->
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-danger" data-dismiss="modal">
                                                        Close
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php
                                }
                            ?>
                        </tbody>
                    </table>
                   
</div>

<script>
	
$(function(){
	$("#check").click(function(){
     
     if($("#check").prop("checked")==true){
     	$("#sn").val($("#bn").val());
     	$("#sp").val($("#bp").val());
     	$("#sa").val($("#ba").val());
     }else{
     	$("#sn").val("");
     	$("#sp").val("");
     	$("#sa").val("");
     }

	});
})

// prop mean Property
</script>








<!-- Footer Area include -->
<?php $this->load->view("./frontend/footer.php"); ?>