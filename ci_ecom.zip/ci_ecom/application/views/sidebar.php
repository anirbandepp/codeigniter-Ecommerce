<?php  
	$res = $this->Frontend_mod->sidebar_cat();

	foreach($res as $r) {

?>
	<div class="list-group mt-2">
	  <button type="button" class="list-group-item list-group-item-action" onclick="cat(<?php echo $r->id;?>)">
	   	<?php echo $r->cat;?>
	  </button>
	</div>
<?php	
	}
?>

<script>
	function cat(id) {

		$.ajax({
			url : "<?php echo base_url();?>category-product",
			type : 'POST',
			data : {cid : id},
			success : function(resp) {
				console.log(resp);
				$("#catProduct").html(resp);
			}
		});
	}
</script>