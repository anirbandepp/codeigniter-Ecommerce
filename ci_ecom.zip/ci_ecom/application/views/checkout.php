<!-- Header Area include -->
<?php $this->load->view("./frontend/header.php"); ?>
<!-- Navbar Area include -->
<?php $this->load->view("./frontend/navbar.php"); ?>

<div class="container pt-4">
	<form action="<?php echo base_url()?>confirm_order" method="POST">
		<div class="row">
			<div class="col-md-6">
					<h2>Billing Address</h2>
					<p>Enter your correct info</p>
					<p>Billing Name</p>
					<p><input type="text" name="bn" id="bn" class="form-control"></p>
					<p>Billing Phone No</p>
					<p><input type="text" name="bp" id="bp" class="form-control"></p>
					<p>Billing Address</p>
					<p>
						<textarea name="ba" id="ba" class="form-control"> </textarea>
					</p>
			</div>
			<div class="col-md-6">
					<h2>Shipping Address</h2>
					<p><label><input type="checkbox" name="check" id="check"> Shipping Address</label></p>
					<p>Shipping Name</p>
					<p><input type="text" name="sn" id="sn" class="form-control"></p>
					<p>Shipping Phone No</p>
					<p><input type="text" name="sp" id="sp" class="form-control"></p>
					<p>Shipping Address</p>
					<p>
						<textarea name="sa" id="sa" class="form-control"> </textarea>
					</p>
					<p class="text-right"> 
						<button value="submit" class="btn btn-primary">Submit</button> 
					</p>
			</div>
		</div>
	</form>
</div>

<script>
	
$(function(){
	$("#check").click(function(){
     
     if($("#check").prop("checked")==true){
     	$("#sn").val($("#bn").val());
     	$("#sp").val($("#bp").val());
     	$("#sa").val($("#ba").val());
     }else{
     	$("#sn").val("");
     	$("#sp").val("");
     	$("#sa").val("");
     }

	});
})

// prop mean Property
</script>








<!-- Footer Area include -->
<?php $this->load->view("./frontend/footer.php"); ?>