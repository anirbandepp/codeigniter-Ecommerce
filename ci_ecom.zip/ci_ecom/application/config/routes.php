<?php
defined('BASEPATH') OR exit('No direct script access allowed');


$route['default_controller'] = 'Home/index';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

// Custom Route For Admin Area
$route['cpnale/dashboard'] = 'Admin/dashboard';

// Add Category Route
$route['cpnale/add-category'] = 'Admin/addCategory';
$route['cpnale/ins-category'] = 'Admin/insCategory';

// Add Sub-Category Route
$route['cpnale/add-sub-category'] = 'Admin/addSubCat';
$route['cpnale/ins-sub-category'] = 'Admin/insSubCat';

// View Category Route
$route['cpnale/view-category'] = 'Admin/selCat';
$route['cpnale/view-category/(:num)'] = 'Admin/selCat/$1';

// Product Form Route
$route['cpnale/add-product'] = 'Admin/addProduct';

// Add Product Route
$route['cpnale/ins-product'] = 'Admin/insProduct';

// View Product 
$route['cpnale/sel-product'] = 'Admin/selProduct';
$route['cpnale/sel-product/(:num)'] = 'Admin/selProduct/$1';

// Delete Product
$route['cpnale/del-product/(:any)'] = 'Admin/delProduct/$1';

// Update Product
$route['cpnale/upd-product/(:any)'] = 'Admin/updProduct/$1';

// Edit Product
$route['cpnale/edit-product'] = 'Admin/editProduct';


// Admin Login View
$route['cpnale/login'] = 'LoginC/alogin';

// Admin Loing Check 
$route['cpnale/login-check'] = 'LoginC/loginCheck';

// Admin Loingout 
$route['cpnale/login-out'] = 'Admin/loginout';

// Frontend Customer Login
$route['cLogin'] = 'Home/cLogin';

// Frontend Customer Logout
$route['cLogOut'] = 'Home/cLogOut';

// Frontend Project Search
$route['search/(:any)']='Home/psearch/$1';

// Frontend Add to cart
$route['add-to-cart'] = 'Home/ins_cart';

// Frontend view cart
$route['view-cart'] = 'Home/view_cart';

// Front cart update
$route['cart-update'] = 'Home/cart_upd';

// Front Prodcut show category wise
$route['category-product'] = 'Home/cat_product';

// Front checkout
$route['checkout'] = 'Home/checkOut';

// Front Confirm Order
$route['confirm_order'] = 'Home/confirmOrder';


// C-Panel View Order
$route['cpnale/view-order'] = 'Admin/viewOrders';

// C-Panel View Order
$route['cpnale/print-order/(:any)'] = 'Admin/printOrders/$1';

// Frontend payment Process
$route['payment_process'] = 'Home/paymentProcess';

// Frontend Thank you
$route['thank_you'] = 'Home/thankYou';

// Frontend Order Histroy
$route['order_history'] = 'Home/orderHistory';

