<?php  

class Admin extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->database();
		$this->load->model('Admin_mod');
		$this->load->library('pagination');
		$this->load->library("session");

		$admin_id = $this->session->userdata("admin_id");

		if($admin_id==""){
			redirect(base_url().'cpnale/login');
		}
	}

	// Load dashboard
	public function dashboard() {
		$this->load->view('dashboard');
	}

	// Category
	public function addCategory() {

		$res = $this->Admin_mod->sel_parent();

		$w = array(
			'parent' => $res
		);

		$this->load->view('admin/add_category',$w);
	}

	public function insCategory() {
		$cat = $this->input->post("addCat");
		$pcat = $this->input->post("pid");
		
		$w = array(
			'cat' => $cat,
			'parent_id' => $pcat
		);
		
		$this->Admin_mod->ins_cat($w);
		redirect(base_url().'cpnale/add-sub-category');
	}

	// Sub-Category	
	public function addSubCat() {

		$res =$this->Admin_mod->sel_cat();

		$w = array(
			'row' => $res
		);

		$this->load->view('admin/add_subcategory', $w);
	}

	public function insSubCat() {
		$catID = $this->input->post("subcat");
		$subcat = $this->input->post("sub_cat");

		$w = array(
			'sub_cat' => $subcat,
			'cat_id'  => $catID
		);

		$this->Admin_mod->ins_sub_cat($w);
		redirect(base_url().'cpnale/add-sub-category');
	}

	public function selCat() {

		$x = array(
			'base_url' => base_url().'cpnale/view-category',
			'per_page' => 3,
			'total_rows' => $this->Admin_mod->sel_all_category() ,
			'attributes'=>array('class'=>'page-link')
		);

		$this->pagination->initialize($x);

		$offset = $this->uri->segment(3);

		if($offset==""){
			$offset=0;
		}

		$res = $this->Admin_mod->sel_all_cat(3,$offset); 

		$w = array(
			'row' => $res
		);

		$this->load->view('admin/view-category',$w);
	}

	// Product Add Form
	public function addProduct() {

		$res = $this->Admin_mod->sel_parent();

		$w = array(
			'row' => $res
		);

		$this->load->view('admin/add_product',$w);
	}

	// Product Insert 
	public function insProduct() {

		$cat = $this->input->post("category");
		$pname = $this->input->post("pname");
		$price = $this->input->post("price");

		$conf = array(
			'upload_path' => './upload_img',
			'allowed_types' => 'jpg|png|jpeg',
			'max_size' => 5000 
		);

		$this->load->library("upload", $conf);

		if(!$this->upload->do_upload("propic")){

			echo $this->upload->display_errors();

		}else{
			$fd = $this->upload->data();
			$fn = $fd['file_name'];

			$w = array(
				'cat' => $cat,
				'pname' => $pname,
				'price' => $price,
				'pimg' => $fn
			);

			$this->Admin_mod->ins_product($w);
			redirect(base_url().'cpnale/sel-product/');
		}
	}

	// Product Select All 
	public function selProduct() {

		$x = array(
			'base_url' => base_url().'cpnale/sel-product',
			'per_page' => 3,
			'total_rows' => $this->Admin_mod->sel_all_product(),
			'attributes'=> array('class'=>'page-link')
		);

		$this->pagination->initialize($x);

		$offset = $this->uri->segment(3);

		if($offset==""){
			$offset=0;
		}

		$res = $this->Admin_mod->sel_product(3,$offset);

		$w = array(
			'row' => $res
		);

		$this->load->view('admin/view_product',$w);
	}

	// Product Delete and Delete image From Folder
	public function delProduct($id) {
		$this->Admin_mod->del_product($id);
		redirect(base_url().'cpnale/sel-product/');
	}

	// Product Update 
	public function updProduct($id) {
		$res = $this->Admin_mod->upd_product($id);
		$cat = $this->Admin_mod->sel_cat();

		$w = array(
			'row' => $res,
			'cat' => $cat
		);

		$this->load->view('admin/upd_product',$w);
	}

	// Edit Product
	public function editProduct(){
		
		$id = $this->input->post("id");
		$cat = $this->input->post("category");
		$pname = $this->input->post("pname");
		$price = $this->input->post("price");

		$conf = array(
			'upload_path' => './upload_img',
			'allowed_types' => 'jpg|png|jpeg',
			'max_size' => 5000 
		);

		$this->load->library("upload", $conf);

		if(!$this->upload->do_upload("propic")){

			$w = array(
				'cat' => $cat,
				'pname' => $pname,
				'price' => $price,
			);

		}else{
			$fd = $this->upload->data();
			$fn = $fd['file_name'];

			$w = array(
				'cat' => $cat,
				'pname' => $pname,
				'price' => $price,
				'pimg' => $fn
			);
		}

		$this->Admin_mod->edit_product($w,$id);
		redirect(base_url().'cpnale/sel-product/');
	}

	// Logout Area
	public function loginout() {
		$this->session->unset_userdata("admin_id");
		$this->session->unset_userdata("admin_name");
		redirect(base_url().'cpnale/login');
	}

	// View Orders
	public function viewOrders() {

		$res = $this->Admin_mod->sel_all_order();

		$w = array(
			'row' => $res
		);

		$this->load->view('admin/view_order',$w);
	}

	// Print Orders
	public function printOrders($id){

		$res = $this->Admin_mod->print_order($id);

		$w = array(
			'row' => $res
		);

		$this->load->view("admin/print_order",$w);
	}

}

?>