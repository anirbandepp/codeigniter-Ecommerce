<?php  

class LoginC extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->database();
		$this->load->model('Login_mod');
		$this->load->library('pagination');
		$this->load->library("session");
	}

	public function alogin() {
		$this->load->view('admin/login_admin');
	}

	public function loginCheck() {
		$e = $this->input->post("email");
		$p = $this->input->post("pass");

		$rs = $this->Login_mod->lc($e,$p);
		if(count($rs)>0){
			foreach($rs as $r){
				$this->session->set_userdata("admin_id",$r->id);
				$this->session->set_userdata("admin_name",$r->name);
				redirect(base_url().'cpnale/dashboard');
			}
		}else{
			$this->session->set_flashdata('msg', 'Invalid login');
			redirect(base_url()."cpnale/login");
		}
	}

}	


?>