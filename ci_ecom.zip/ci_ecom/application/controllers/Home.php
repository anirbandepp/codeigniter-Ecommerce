<?php  

class Home extends CI_Controller {

	function __construct() {
		parent::__construct();
		$this->load->helper('url');
		$this->load->database();
		$this->load->model('Frontend_mod');
		$this->load->library('pagination');
		$this->load->library("session");
	}

	public function index(){
		$res = $this->Frontend_mod->sel_product();

		$w = array(
			'row' => $res
		);

		$this->load->view('Home.php',$w);
	}

	public function cLogin() {
		$n = $this->input->post("email");
		$p = $this->input->post("password");

		$res=$this->Frontend_mod->customer_login_check($n,$p);
		if(count($res)>0){
			$this->session->set_userdata("cname",$res[0]->name);
			$this->session->set_userdata("cid",$res[0]->cid);
			redirect("/");
		}else{
      ?>
         <script> 
         	alert("Invalid Login"); 
          	window.location='<?php echo base_url(); ?>';
      	</script>
      <?php
		}
	}

	public function cLogOut() {
		$this->session->unset_userdata("cname");
		$this->session->unset_userdata("cid");
		redirect("/");
	}	

	public function psearch($s) {
		$res = $this->Frontend_mod->search_product($s);

		$w = array(
			'row' => $res
		);

		$this->load->view('Home.php',$w);
	}

	public function ins_cart() {
		$this->Frontend_mod->insc();
	}	

	public function view_cart() {
		$cname = $this->session->userdata("cname");
		$cid = $this->session->userdata("cid");
		$cart_count = 0;

		if($cname != "") {

			$res = $this->Frontend_mod->show_cart($cid);	
		
			$w = array(
				'row' => $res
			);

			$this->load->view("view-cart.php",$w);

		}else{
			echo "Pls login for check your cart";
		}
	}

	public function cart_upd() {
		$this->Frontend_mod->cart_update();

		$cname = $this->session->userdata("cname");
		$cid = $this->session->userdata("cid");
		$cart_count = 0;

		if($cname != "") {

			$res = $this->Frontend_mod->show_cart($cid);	
		
			$w = array(
				'row' => $res
			);

			$this->load->view("cart_upd.php",$w);
		}	
	}

	public function cat_product() {

		$res =$this->Frontend_mod->sel_cat_product();

		$w = array(
			'row' => $res
		);

		$this->load->view("cat_product.php",$w);
	}

	public function checkOut() {
		$this->load->view("checkout.php");
	}

	public function confirmOrder() {

		$bn = $this->input->post('bn');
		$bp = $this->input->post('bp');
		$ba = $this->input->post('ba');

		$sn = $this->input->post('sn');
		$sp = $this->input->post('sp');
		$sa = $this->input->post('sa');

		$cid = $this->session->userdata("cid");

		$w = array(
			'bn' => $bn,
			'bp' => $bp,
			'ba' => $ba,
			'sn' => $sn,
			'sp' => $sp,
			'sa' => $sa,
			'cid' => $cid,
			'paymentStatus' => 'pending'
		);

		$gt=$this->Frontend_mod->main_order($w);

		$data=array(
	     'gt'=>$gt,
	     'name'=>$bn
		);

		$this->load->view('paymentGateway',$data);
	}

	public function paymentProcess() {

		$payment_id = $this->input->post("payment_id");
		
		$oid=$this->session->userdata("order_id");

		if($payment_id!=""){
			$w=array(
	         'paymentID' => $payment_id,
	         'paymentStatus' => 'complete'
			);
			
			$this->Frontend_mod->paymentSuccess($w,$oid);
		}
	}

	public function thankYou() {
		$this->load->view('thankyou');
	}

	public function orderHistory() {

		$res = $this->Frontend_mod->userOrderHistory();

		$w = array(
			'row' => $res
		);

		$this->load->view('order_history', $w);
	}

}

?>