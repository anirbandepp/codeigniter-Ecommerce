<?php  

class Admin_mod extends CI_Model {

	// Category INSERT
	public function ins_cat($data) {
		$this->db->insert("category",$data);
	}

	// Category SELECT
	public function sel_cat() {
		$q = $this->db->get("category");
		$rs = $q->result();
		return $rs;
	}

	// Category SELECT PARENT
	public function sel_parent() {
		$this->db->where("parent_id",0);
		$q = $this->db->get("category");
		return $res = $q->result();
	}

	// Category INSERT SUB CATEGORY
	public function ins_sub_cat($data) {
		$this->db->insert("sub_category",$data);
	}

	// Category SELECT USING LEFT JOINING
	public function sel_all_cat($n,$o) {
		$this->db->limit($n,$o);
		$this->db->select('a.*,b.cat as parentname');
		$this->db->from('category as a');
		$this->db->join('category as b','a.parent_id = b.id',"left");
		$q = $this->db->get();
		return $res = $q->result();
	}

	// Category SELECT ID
	public function sub_cat($cid) {
		$this->db->where("parent_id",$cid);
		$q = $this->db->get("category");
		return $res = $q->result();
	}

	// PRODUCT INSERT
	public function ins_product($data) {
		$this->db->insert("product",$data);
	}

	// PRODUCT SELECT
	public function sel_product($pp, $offset) {
		$this->db->select("product.*,category.cat as catname");
		$this->db->from("product");
		$this->db->join("category", 'product.cat = category.id');
		$this->db->limit($pp, $offset);
		$q = $this->db->get();
		return $rs = $q->result();
	}

	// PRODUCT DELETE
	public function del_product($id) {

		$this->db->where("pid",$id);
		$q = $this->db->get("product");
		$res = $q->result();
		foreach ($res as $r) {
			unlink('./upload_img/'.$r->pimg);
		}

		$this->db->where("pid",$id);
		$this->db->delete("product");
	}	

	// PRODUCT SELECT USING ID FOR UPDATE
	public function upd_product($id) {
		$this->db->where("pid",$id);
		$q = $this->db->get("product");
		return $rs = $q->result();
	}	

	// PRODUCT UPDATE
	public function edit_product($data,$id) {
		$this->db->where("pid",$id);
		$this->db->update("product",$data);
	}

	// SELECT CATEGORY FOR PAGINATION
	public function sel_all_category() {
		$q = $this->db->get("category");
		$res = $q->result();
		return count($res);
	}

	// Select All PRODUCT FOR PAGINATION
	public function sel_all_product() {
		$q = $this->db->get("product");
		$res = $q->result();
		return count($res);
	}

	// SELECT ORDER FROM ADMIN PANEL
	public function sel_all_order() {
		$q = $this->db->get("main_order");
		$rs = $q->result();
		return $rs;
	}

	// SELECT ORDER FROM SUB-TABLE
	public function sel_order($id) {
		$this->db->where("order_ID",$id);
		$q = $this->db->get("sub_table");
		return $rs = $q->result();
	}

	// SELECT CUSTOMER NAME FOR ORDER TABLE
	public function cname($cid) {
		$this->db->where("cid",$cid);
		$q = $this->db->get("customer");
		$res = $q->result();
		return $res;
	}

	// SELECT PRODUCT NAME FOR ORDER TABLE
	public function pname($pid) {
		$this->db->where("pid",$pid);
		$q = $this->db->get("product");
		$res = $q->result();
		return $res;
	}

	// SELECT SINGLE RECORD FOR PRINT BILL
	public function print_order($id){
		$this->db->where("id",$id);
		$q = $this->db->get("main_order");
		return $rs = $q->result();
	}

}

?>