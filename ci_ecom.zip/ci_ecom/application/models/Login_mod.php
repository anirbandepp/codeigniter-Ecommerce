<?php  


class Login_mod extends CI_Model {
	
	public function lc($e,$p) {
		$this->db->where("email",$e);
		$this->db->where("password",$p);
		$q = $this->db->get("admin");
		return $rs = $q->result();
	}
}

?>