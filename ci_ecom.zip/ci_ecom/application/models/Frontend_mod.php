<?php  

class Frontend_mod extends CI_Model
{
	
	public function sel_product() {
		$this->db->select("product.*,category.cat as catname");
		$this->db->from("product");
		$this->db->join("category", 'product.cat = category.id');
		$q = $this->db->get();
		return $rs = $q->result();
	}

	public function customer_login_check($n,$p) {
		$this->db->where("email",$n);
		$this->db->where("password",$p);
		$q = $this->db->get("customer");
		$res = $q->result();
		return $res;
	}

	public function search_product($s){
		$this->db->where("product.pname LIKE '%$s%'");
		$this->db->select("product.*,category.cat as catname");
		$this->db->from("product");
		$this->db->join("category", 'product.cat = category.id');

		$q = $this->db->get();
		return $rs = $q->result();
	}

	public function insc() {
		$cid=$this->session->userdata("cid");
		$pid = $this->input->post("pid");
		$price = $this->input->post("price");
		$qty = $this->input->post("qty");

		$this->db->where("pid",$pid);
		$this->db->where("cid",$cid);
		$q = $this->db->get("cart");
		$res = $q->result();
			if(count($res)>0) {
				$w=array(
					'qty' => $qty+$res[0]->qty
				);
				$this->db->where("pid",$pid);
				$this->db->where("cid",$cid);
				$this->db->update("cart",$w);	

			}else{

			$w = array(
				'pid' => $pid,
				'cid' => $cid,
				'qty' => $qty,
				'price' => $price
			);

			$this->db->insert("cart",$w);
			redirect(base_url().'view-cart');
		}
	}

	public function show_cart($cid) {
		$this->db->select("*");
		$this->db->from("cart");
		$this->db->join("product", 'product.pid = cart.pid', 'inner');
		$this->db->where("cid",$cid);
		$q = $this->db->get();
		$res = $q->result();
		return $res;
	}

	public function cart_update() {
		$cid=$this->session->userdata("cid");
		$cartID = $this->input->post("cartid");
		$qty = $this->input->post("qty");

		$this->db->where("cartid",$cartID);
		$this->db->where("cid",$cid);
		$q = $this->db->get("cart");
		$res = $q->result();

		if(count($res)>0) {
			$w=array(
				'qty' => $qty
			);
		}else{
			echo "Not Updated";
		}

		$this->db->where("cartid",$cartID);
		$this->db->update("cart",$w);
	}

	public function sidebar_cat() {
		$this->db->where("parent_id !=", 0);
		$q = $this->db->get("category");
		$rs = $q->result();
		return $rs; 
	}

	public function sel_cat_product() {
		$catID = $this->input->post("cid");

		$this->db->select("product.*,category.cat as catname");
		$this->db->from("product");
		$this->db->join("category", 'product.cat = category.id');
		$this->db->where("product.cat",$catID);
		$q = $this->db->get();
		return $rs = $q->result();
	}

	public function main_order($data) {
		$this->db->insert("main_order",$data);

		$order_id = $this->db->insert_id();
		$this->session->set_userdata("order_id",$order_id);

		$cid = $this->session->userdata("cid");
		$this->db->where("cid",$cid);
		$q = $this->db->get("cart");
		$rs = $q->result();

		$gt=0;
		
		foreach($rs as $r) {

			$pid = $r->pid;
			$cid = $r->cid;
			$qty = $r->qty;
			$price = $r->price;
			$gt=$gt+($price*$qty);

			$w = array(
				'pid' => $pid,
				'cid' => $cid,
				'qty' => $qty,
				'price' => $price,
				'order_ID' => $order_id
			);

			$this->db->insert("sub_table",$w);
		}

		$this->db->where("cid",$cid);
		$this->db->delete("cart");
		return $gt; 
	}

	public function paymentSuccess($w,$oid) {
		$this->db->where("id",$oid);
		$this->db->update("main_order",$w);
	}

	public function userOrderHistory() {
		$cid = $this->session->userdata("cid");
		$this->db->where("cid",$cid);
		$q = $this->db->get("main_order");
		$res = $q->result();
		return $res;
	}

	public function sel_order($id) {
		$this->db->where("order_ID",$id);
		$q = $this->db->get("sub_table");
		return $rs = $q->result();
	}

	public function pname($pid) {
		$this->db->where("pid",$pid);
		$q = $this->db->get("product");
		$res = $q->result();
		return $res;
	}

	public function cartCounter(){
		$cid = $this->session->userdata("cid");
		$this->db->where("cid",$cid);
		$q = $this->db->get("cart");
		$res = $q->result();
		$tqty=0;
		foreach($res as $r){
			$tqty=$tqty+$r->qty;
		}
		return $tqty;

	}
}

?>